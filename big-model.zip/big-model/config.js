const ORIGIN = 'http://172.16.10.220:30855'
window.global_config = {
  BASE_URL: "/api",
  //BASE_URL: ORIGIN + ':5050',
  showWarehouse: true,
  localData: true,
}

